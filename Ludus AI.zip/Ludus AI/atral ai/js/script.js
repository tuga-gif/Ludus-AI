const ANIMATION_DURATION = 4000

const REDIRECT_PAGE = 'inicio.html';

setTimeout(() => {
    document.body.style.transition = 'opacity 0.5s ease';
    document.body.style.opacity = '0';
    
    setTimeout(() => {
        window.location.href = REDIRECT_PAGE;
    }, 500);
}, ANIMATION_DURATION);

document.addEventListener('click', () => {
    if (document.body.style.opacity !== '0') {
        document.body.style.transition = 'opacity 0.3s ease';
        document.body.style.opacity = '0';
        
        setTimeout(() => {
            window.location.href = REDIRECT_PAGE;
        }, 300);
    }
});

document.addEventListener('keydown', (e) => {
    if ((e.key === 'Escape' || e.key === 'Enter') && document.body.style.opacity !== '0') {
        document.body.style.transition = 'opacity 0.3s ease';
        document.body.style.opacity = '0';
        
        setTimeout(() => {
            window.location.href = REDIRECT_PAGE;
        }, 300);
    }
});