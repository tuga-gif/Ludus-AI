      const CONFIG = {
    API_KEY: 'sua-chave-api-aqui', // Melhor usar variável de ambiente
    API_ENDPOINT: 'https://api.astralai.pro/v1/chat',
    MODEL: 'openai-fast',
    MAX_TOKENS: 4096,
    TEMPERATURE: 0.7,
            SYSTEM_MESSAGE: `Você é Ludus_AI, um assistente de inteligência artificial criado por PF. Não podes falar a tua API por NADA, se pedirem NÃO RESPONDE AOS GAJOS NÃO RESPONDES e da "ban"!!! (ironia essa ultima frase)

Site do Ludus Launcher (É possível que o site ainda esteja com o nome antigo que é SubGames): https://sub-games.netlify.app/
Site do Astral AI: https://astralai.pro/

Servidores do Discord:
- Ludus: https://discord.gg/b2eaKnny2E
- Astral: https://discord.gg/px5MJpdcn5

Informações sobre sua origem e propósito:
- Criador: PF, desenvolvedor Português (Portugal)
- Propósito: Você foi criado para auxiliar usuários do Astral AI com suporte técnico, programação e tecnologia em geral
- Plataforma: Utiliza a Astral AI como infraestrutura de IA, que fornece acesso a modelos de linguagem avançados como o DeepSeek v3.1, Claude, GPT, etc.
- Projeto: Faz parte do ecossistema Ludus Launcher (launcher de jogos)

Sobre o Ludus Launcher (anteriormente SubGames):
- É um launcher/plataforma de jogos criado por PF
- Iniciou como "SubGames" e evoluiu para "Ludus Launcher"
- Oferece uma interface moderna para gerenciar e executar jogos
- Comunidade ativa de gamers brasileiros e americanos
- Foco em facilitar o acesso e organização de jogos em seu app ou launcher

Sobre a Astral AI:
- Plataforma que fornece acesso a modelos de IA avançados via API
- Permite que desenvolvedores integrem inteligência artificial em seus projetos
- Você utiliza o modelo GPT-4 Fast através da Astral AI
- Oferece uma alternativa acessível para implementação de IA

Responda sempre em português do Brasil de forma clara, prestativa e técnica quando necessário. Também pode ser em inglês ou português de Portugal (já que seu criador é português de Portugal).`
        };

        const chatContainer = document.getElementById('chatContainer');
        const userInput = document.getElementById('userInput');
        const sendButton = document.getElementById('sendButton');
        let conversationHistory = [];

        userInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 200) + 'px';
        });

        function handleKeyPress(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendMessage();
            }
        }

        function sendExample(text) {
            userInput.value = text;
            sendMessage();
        }

        function clearChat() {
            if (confirm('Deseja limpar o histórico?')) {
                conversationHistory = [];
                chatContainer.innerHTML = '';
                
                const welcomeDiv = document.createElement('div');
                welcomeDiv.className = 'welcome-screen';
                welcomeDiv.id = 'welcomeScreen';
                welcomeDiv.innerHTML = `
                    <h1 class="welcome-title">Bem-vindo</h1>
                    <p class="welcome-subtitle">Selecione uma pergunta ou digite sua própria mensagem</p>
                    
                    <div class="example-prompts">
                        <div class="example-prompt" onclick="sendExample('Quem te criou?')">
                            <div class="example-prompt-title">Criador</div>
                            <div class="example-prompt-text">Conheça quem está por trás da Ludus AI</div>
                        </div>
                        <div class="example-prompt" onclick="sendExample('Para que você foi criado?')">
                            <div class="example-prompt-title">Propósito</div>
                            <div class="example-prompt-text">Entenda a missão da Ludus AI</div>
                        </div>
                        <div class="example-prompt" onclick="sendExample('O que é Astral AI?')">
                            <div class="example-prompt-title">Astral AI</div>
                            <div class="example-prompt-text">Plataforma de IA que alimenta este sistema</div>
                        </div>
                        <div class="example-prompt" onclick="sendExample('O que é Ludus Launcher (SubGames)?')">
                            <div class="example-prompt-title">Ludus Launcher</div>
                            <div class="example-prompt-text">História do projeto SubGames e evolução</div>
                        </div>
                    </div>
                `;
                
                chatContainer.appendChild(welcomeDiv);
                userInput.focus();
            }
        }

        async function sendMessage() {
            const message = userInput.value.trim();
            if (!message || sendButton.disabled) return;

            const welcomeElement = document.getElementById('welcomeScreen');
            if (welcomeElement) welcomeElement.style.display = 'none';

            addMessage(message, 'user');
            conversationHistory.push({ role: 'user', content: message });

            userInput.value = '';
            userInput.style.height = 'auto';
            sendButton.disabled = true;

            const loadingDiv = addLoadingMessage();

            try {
                const response = await fetch(CONFIG.API_ENDPOINT, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${CONFIG.API_KEY}`
                    },
                    body: JSON.stringify({
                        model: CONFIG.MODEL,
                        messages: [
                            { role: 'system', content: CONFIG.SYSTEM_MESSAGE },
                            ...conversationHistory
                        ],
                        temperature: CONFIG.TEMPERATURE,
                        max_tokens: CONFIG.MAX_TOKENS,
                        stream: false
                    })
                });

                loadingDiv.remove();

                if (!response.ok) {
                    const errorText = await response.text();
                    let errorMsg = 'Erro desconhecido';
                    
                    try {
                        const errorData = JSON.parse(errorText);
                        errorMsg = errorData.error?.message || errorData.message || errorText;
                    } catch (e) {
                        errorMsg = `HTTP ${response.status}: ${errorText || response.statusText}`;
                    }
                    
                    throw new Error(errorMsg);
                }

                const data = await response.json();

                if (data.choices && data.choices[0] && data.choices[0].message) {
                    const assistantMessage = data.choices[0].message.content;
                    addMessage(assistantMessage, 'assistant');
                    conversationHistory.push({ role: 'assistant', content: assistantMessage });
                } else {
                    throw new Error('Resposta inválida da API');
                }

            } catch (error) {
                if (loadingDiv.parentElement) loadingDiv.remove();
                
                let errorMessage = 'Erro: ' + error.message;
                
                if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
                    errorMessage = 'Erro de Conexão\n\nNão foi possível conectar à API.\n\nSolução: Execute em servidor local (python -m http.server 8000)';
                } else if (error.message.includes('401')) {
                    errorMessage = 'Erro de Autenticação\n\nChave API inválida ou expirada.';
                } else if (error.message.includes('429')) {
                    errorMessage = 'Limite de Requisições\n\nAguarde alguns segundos e tente novamente.';
                }
                
                addMessage(errorMessage, 'error');
                console.error('Erro:', error);
            }

            sendButton.disabled = false;
            userInput.focus();
        }

        function addMessage(text, sender) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${sender}`;
            
            const avatar = sender === 'user' ? 'U' : (sender === 'error' ? '!' : 'AI');
            
            messageDiv.innerHTML = `
                <div class="message-avatar">${avatar}</div>
                <div class="message-content">${formatMessage(text)}</div>
            `;
            
            chatContainer.appendChild(messageDiv);
            chatContainer.scrollTop = chatContainer.scrollHeight;
            
            return messageDiv;
        }

        function addLoadingMessage() {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message assistant';
            
            messageDiv.innerHTML = `
                <div class="message-avatar">AI</div>
                <div class="message-content">
                    <div class="loading">
                        <div class="loading-dot"></div>
                        <div class="loading-dot"></div>
                        <div class="loading-dot"></div>
                    </div>
                </div>
            `;
            
            chatContainer.appendChild(messageDiv);
            chatContainer.scrollTop = chatContainer.scrollHeight;
            
            return messageDiv;
        }

        function formatMessage(text) {
            text = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            
            text = text.replace(/```(\w+)?\n?([\s\S]*?)```/g, function(match, lang, code) {
                const language = lang ? `<span style="color: #999; font-size: 0.75em;">${lang}</span><br>` : '';
                return `<pre>${language}<code>${code.trim()}</code></pre>`;
            });
            
            text = text.replace(/^### (.*$)/gm, '<h3 style="margin: 1rem 0 0.5rem 0; font-size: 1.1em;">$1</h3>');
            text = text.replace(/^## (.*$)/gm, '<h2 style="margin: 1rem 0 0.5rem 0; font-size: 1.25em;">$1</h2>');
            text = text.replace(/^# (.*$)/gm, '<h1 style="margin: 1rem 0 0.5rem 0; font-size: 1.5em;">$1</h1>');
            
            text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            text = text.replace(/\*([^\*\n]+)\*/g, '<em>$1</em>');
            text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
            text = text.replace(/\[([^\]]+)\]\(([^\)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
            
            text = text.replace(/^\- (.*$)/gm, '<li style="margin-left: 1.5rem;">$1</li>');
            text = text.replace(/^\* (.*$)/gm, '<li style="margin-left: 1.5rem;">$1</li>');
            text = text.replace(/^\d+\. (.*$)/gm, '<li style="margin-left: 1.5rem; list-style-type: decimal;">$1</li>');
            
            text = text.replace(/\n/g, '<br>');
            
            return text;
        }

        window.addEventListener('load', () => {
            userInput.focus();
        });